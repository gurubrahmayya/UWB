#using Venn circles
import serial
from time import sleep
import math
import turtle
import sympy as sp

ser1 = serial.Serial(port='COM24', baudrate=115200, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE,
                    bytesize=serial.EIGHTBITS, timeout=0)
ser1.flush()
print("connected to: " + ser1.portstr)

ser2 = serial.Serial(port='COM22', baudrate=115200, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE,
                    bytesize=serial.EIGHTBITS, timeout=0)
ser2.flush()
print("connected to: " + ser2.portstr)

ser3 = serial.Serial(port='COM26', baudrate=115200, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE,
                    bytesize=serial.EIGHTBITS, timeout=0)
ser3.flush()
print("connected to: " + ser3.portstr)

def screen_init(width=5000, height=1000, t=turtle):
    t.setup(width, height)
    t.tracer(False)
    t.hideturtle()
    t.speed(0)


def turtle_init(t=turtle):
    t.hideturtle()
    t.speed(0)


def draw_line(x0, y0, x1, y1, color="black", t=turtle):
    t.pencolor(color)
    t.up()
    t.goto(x0, y0)
    t.down()
    t.goto(x1, y1)
    t.up()
    t.hideturtle()

def draw_fastU(x, y, length, color="black", t=turtle):
    draw_line(x, y, x, y + length, color, t)


def draw_fastV(x, y, length, color="black", t=turtle):
    draw_line(x, y, x + length, y, color, t)


def draw_cycle(x, y, r, color="black", t=turtle):
    t.pencolor(color)
    t.up()
    t.goto(x, y - r)
    t.setheading(0)
    t.down()
    t.circle(r)
    t.up()

def fn_draw_cycle(x, y, r, color, t):
    draw_cycle(x, y, r, color, t)


def fill_cycle(x, y, r, color="black", t=turtle):
    t.up()
    t.goto(x, y)
    t.down()
    t.dot(r, color)
    t.up()

def write_txt(x, y, txt, color="black", t=turtle, f=('Arial', 12, 'normal')):

    t.pencolor(color)
    t.up()
    t.goto(x, y)
    t.down()
    t.write(txt, move=False, align='left', font=f)
    t.up()


def draw_rect(x, y, w, h, color, t=turtle):
    t.pencolor(color)
    t.up()
    t.goto(x, y)
    t.down()
    t.goto(x + w, y)
    t.goto(x + w, y + h)
    t.goto(x, y + h)
    t.goto(x, y)
    t.up()


def fill_rect(x, y, w, h, color=("black", "black"), t=turtle):
    t.begin_fill()
    draw_rect(x, y, w, h, color, t)
    t.end_fill()
    pass


def clean(t=turtle):
    t.clear()


def draw_ui(t):
    write_txt(-300, 250, "Localization by circle intersection", "black",  t, f=('Arial', 32, 'normal'))
    draw_line(-400, 0, 400, 0) #for X-axis
    draw_line(0, -400, 0, 400)  # for X-axis
    # fill_rect(-400, 200, 800, 40, "black", t)
    # write_txt(-50, 205, "WALL", "yellow",  t, f=('Arial', 24, 'normal'))


def draw_uwb_anchor1(x, y, txt, range, color, t):
    r = 10
    fill_cycle(x, y, r, color, t)
    write_txt(x-150, y-30, txt + ": " + str(range) + "cm", "green",  t, f=('Arial', 16, 'normal'))
    t.pencolor(color)
    t.up()
    t.goto(x, y - range)
    t.setheading(0)
    t.down()
    t.circle(range)
    t.up()

def draw_uwb_anchor2(x, y, txt, range, color, t):
    r = 10
    fill_cycle(x, y, r, color, t)
    write_txt(x + 50, y - 30, txt + ": " + str(range) + "cm", "red", t, f=('Arial', 16, 'normal'))
    t.pencolor(color)
    t.up()
    t.goto(x, y - range)
    t.setheading(0)
    t.down()
    t.circle(range)
    t.up()

def draw_uwb_anchor3(x, y, txt, range, t):
    r = 20
    fill_cycle(x, y, r, "green", t)
    write_txt(x + r, y-20, txt + ": " + str(range) + "cm",
              "black",  t, f=('Arial', 16, 'normal'))

def draw_uwb_tag(x, y, txt, range, color, t):
    r = 20
    fill_cycle(x, y, r, color, t)
    write_txt(x + r, y, txt + ": " + str(range) + "cm",
              color,  t, f=('Arial', 16, 'normal'))

def distance(x1, y1, x2, y2):
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)

def nearest_point_to_circle(x1, y1, x2, y2, xc, yc, r):
    dist1 = distance(x1, y1, xc, yc)
    dist2 = distance(x2, y2, xc, yc)
    if(abs(dist1-r) < abs(dist2-r)):
        return (x1, y1)
    else:
        return (x2, y2)

def main():
    # ser1.flushOutput()
    ser1.flushInput()
    # ser2.flushOutput()
    ser2.flushInput()
    # ser3.flushOutput()
    ser3.flushInput()
    # Define the variables
    x, y = sp.symbols('x y')

    t_ui = turtle.Turtle()
    t_a1 = turtle.Turtle()
    t_a2 = turtle.Turtle()
    t_a3 = turtle.Turtle()
    t_a4 = turtle.Turtle()
    t_a5 = turtle.Turtle()

    turtle_init(t_ui)
    turtle_init(t_a1)
    turtle_init(t_a2)
    turtle_init(t_a3)
    turtle_init(t_a4)
    turtle_init(t_a5)


    draw_ui(t_ui)
    draw_rect(-80, -150, 160, 200, "aquamarine4")  # rectangle to draw car boundaries
    draw_rect(-150, -200, 300, 300, "DarkMagenta")  # rectangle to draw unlock boundaries
    # str_a = "10"
    # str_b = "80"
    # str_c = "80"
    while True:
        try:
            byte_a = ser1.readline()
            str_a = byte_a.decode().rstrip()
            int_a = abs(int(float(str_a)))
        except:
            int_a = 1
        try:
            byte_b = ser2.readline()
            str_b = byte_b.decode().rstrip()
            int_b = abs(int(float(str_b)))
        except:
            int_b = 1
        try:
            byte_c = ser3.readline()
            str_c = byte_c.decode().rstrip()
            int_c = abs(int(float(str_c)))
        except:
            int_c = 1
        #ser1.flushOutput()
        ser1.flushInput()
        #ser2.flushOutput()
        ser2.flushInput()
        #ser3.flushOutput()
        ser3.flushInput()
        print("a: " + str(int_a))
        print("b: " + str(int_b))
        print("c: " + str(int_c))
        draw_uwb_anchor1(-50, 0, "A1(-50,0)", int_a, "green", t_a1)
        draw_uwb_anchor2(50, 0, "A2(50,0)", int_b, "red", t_a2)
        draw_uwb_anchor1(0, -100, "A3(0, -100)", int_c, "blue", t_a3)

        # Define the equations
        eq1 = sp.Eq((x + 50) ** 2 + (y - 0) ** 2, int(int_a ** 2))
        eq2 = sp.Eq((x - 50) ** 2 + (y - 0) ** 2, int(int_b ** 2))
        eq3 = sp.Eq((x - 0) ** 2 + (y + 100) ** 2, int(int_c ** 2))

        sol = sp.solve((eq1, eq2, eq3), (x, y))
        if (len(sol)):
            a = sol[0]
            x1 = a[0]
            y1 = a[1]
            draw_uwb_tag(x1, y1, "TAG(" + str(round(x1)) + "," + str(round(y1)) + ")",int_b, "brown", t_a4)
            draw_cycle(nearest[0], nearest[1], 5, "brown")
            draw_line(-50, 0, x1, y1, color="yellow")
            draw_line(50, 0, x1, y1, color="yellow")
            draw_line(0, -100, x1, y1, color="yellow")
            # Print the solutions
            print(sol)
            if(x1 > -80 and x1 < 80 and y1 > -150 and y1 < 50):
                print("Inside Car, Engine can start")
            elif(x1 > -150 and x1 < -80 and y1 > -200 and y1 < 100):
                print("Left Side Door Unlock")
            elif (x1 > 80 and x1 < 150 and y1 > -200 and y1 < 100):
                print("Right Side Door Unlock")
            elif (x1 > -80 and x1 < 80 and y1 > -200 and y1 < -150):
                print("Rear Door Unlock")
            else:
                print("Outside Unlock zone")

        else:
            print("3 cicles intersection not possible")
            print("Computing 1 & 2 circles intersection")
            # Solve the system of equations
            sol = sp.solve((eq1, eq2), (x, y))
            arr = sol[0]
            m = arr[0]
            n = arr[1]
            if (not ('I' in str(n))):
                print("Computing 1 & 2 circles intersection not have complex numbers")
                sol_len = len(sol)
                if (sol_len == 2):
                    arr1 = sol[0]
                    x1 = float(arr1[0])
                    y1 = float(arr1[1])
                    arr2 = sol[1]
                    x2 = float(arr2[0])
                    y2 = float(arr2[1])
                    print(sol)
                    if (int_c != 1):  # if A3 doesn't equal to default value 1
                        nearest = nearest_point_to_circle(x1, y1, x2, y2, 0, -100, int_c)
                        print(nearest)
                        draw_uwb_tag(nearest[0], nearest[1], "TAG1(" + str(int(nearest[0])) + "," + str(int(nearest[1])) + ")", int_c, "brown", t_a4)
                        draw_cycle(nearest[0], nearest[1], 5, "brown")
                        if (nearest[0] > -80 and nearest[0] < 80 and nearest[1] > -150 and nearest[1] < 50):
                            print("Inside Car, Engine can start")
                        elif (nearest[0] > -150 and nearest[0] < -80 and nearest[1] > -200 and nearest[1] < 100):
                            print("Left Side Door Unlock")
                        elif (nearest[0] > 80 and nearest[0] < 150 and nearest[1] > -200 and nearest[1] < 100):
                            print("Right Side Door Unlock")
                        elif (nearest[0] > -80 and nearest[0] < 80 and nearest[1] > -200 and nearest[1] < -150):
                            print("Rear Door Unlock")
                        else:
                            print("Outside Unlock zone")
                    else:
                        draw_uwb_tag(x1, y1, "TAG1(" + str(round(x1)) + "," + str(round(y1)) + ")",int_b, "lightgreen", t_a4)
                        draw_uwb_tag(x2, y2, "TAG2(" + str(round(x2)) + "," + str(round(y2)) + ")", int_b, "RosyBrown", t_a4)
                        if (x1 > -80 and x1 < 80 and y1 > -150 and y1 < 50) or (x2 > -80 and x2 < 80 and y2 > -150 and y2 < 50):
                            print("Inside Car, Engine can start")
                        elif (x1 > -150 and x1 < -80 and y1 > -200 and y1 < 100) or (x2 > -150 and x2 < -80 and y2 > -200 and y2 < 100):
                            print("Left Side Door Unlock")
                        elif (x1 > 80 and x1 < 150 and y1 > -200 and y1 < 100) or (x2 > 80 and x2 < 150 and y2 > -200 and y2 < 100):
                            print("Right Side Door Unlock")
                        elif (x1 > -80 and x1 < 80 and y1 > -200 and y1 < -150) or (x2 > -80 and x2 < 80 and y2 > -200 and y2 < -150):
                            print("Rear Door Unlock")
                        else:
                            print("Outside Unlock zone")
                if (sol_len == 1):
                    arr1 = sol[0]
                    x1 = float(arr1[0])
                    y1 = float(arr1[1])
                    draw_uwb_tag(x1, y1, "TAG1(" + str(round(x1)) + "," + str(round(y1)) + ")",int_b, "lightgreen", t_a4)
                    draw_cycle(nearest[0], nearest[1], 5, "brown")
                    print(sol)
                    if (x1 > -80 and x1 < 80 and y1 > -150 and y1 < 50):
                        print("Inside Car, Engine can start")
                    elif (x1 > -150 and x1 < -80 and y1 > -200 and y1 < 100):
                        print("Left Side Door Unlock")
                    elif (x1 > 80 and x1 < 150 and y1 > -200 and y1 < 100):
                        print("Right Side Door Unlock")
                    elif (x1 > -80 and x1 < 80 and y1 > -200 and y1 < -150):
                        print("Rear Door Unlock")
                    else:
                        print("Outside Unlock zone")
            else:
                print("Not possible to compute 1 & 2 circles intersection")
                print("Computing 1 & 3 circles intersection")
                # Solve the system of equations
                sol = sp.solve((eq1, eq3), (x, y))
                arr = sol[0]
                m = arr[0]
                n = arr[1]
                if (not ('I' in str(n))):
                    print("Computing 1 & 3 circles intersection not have complex numbers")
                    sol_len = len(sol)
                    if (sol_len == 2):
                        arr1 = sol[0]
                        x1 = float(arr1[0])
                        y1 = float(arr1[1])
                        arr2 = sol[1]
                        x2 = float(arr2[0])
                        y2 = float(arr2[1])
                        print(sol)
                        if (int_b != 1):  # if A2 doesn't equal to default value 1
                            nearest = nearest_point_to_circle(x1, y1, x2, y2, 50, 0, int_b)
                            print(nearest)
                            draw_uwb_tag(nearest[0], nearest[1], "TAG1(" + str(int(nearest[0])) + "," + str(int(nearest[1])) + ")", int_b, "brown", t_a4)
                            draw_cycle(nearest[0], nearest[1], 5, "brown")
                            if (nearest[0] > -80 and nearest[0] < 80 and nearest[1] > -150 and nearest[1] < 50):
                                print("Inside Car, Engine can start")
                            elif (nearest[0] > -150 and nearest[0] < -80 and nearest[1] > -200 and nearest[1] < 100):
                                print("Left Side Door Unlock")
                            elif (nearest[0] > 80 and nearest[0] < 150 and nearest[1] > -200 and nearest[1] < 100):
                                print("Right Side Door Unlock")
                            elif (nearest[0] > -80 and nearest[0] < 80 and nearest[1] > -200 and nearest[1] < -150):
                                print("Rear Door Unlock")
                            else:
                                print("Outside Unlock zone")
                        else:
                            draw_uwb_tag(x1, y1, "TAG1(" + str(round(x1)) + "," + str(round(y1)) + ")", int_b, "lightgreen", t_a4)
                            draw_uwb_tag(x2, y2, "TAG2(" + str(round(x2)) + "," + str(round(y2)) + ")", int_b, "CadetBlue1", t_a4)
                            if (x1 > -80 and x1 < 80 and y1 > -150 and y1 < 50) or (
                                    x2 > -80 and x2 < 80 and y2 > -150 and y2 < 50):
                                print("Inside Car, Engine can start")
                            elif (x1 > -150 and x1 < -80 and y1 > -200 and y1 < 100) or (
                                    x2 > -150 and x2 < -80 and y2 > -200 and y2 < 100):
                                print("Left Side Door Unlock")
                            elif (x1 > 80 and x1 < 150 and y1 > -200 and y1 < 100) or (
                                    x2 > 80 and x2 < 150 and y2 > -200 and y2 < 100):
                                print("Right Side Door Unlock")
                            elif (x1 > -80 and x1 < 80 and y1 > -200 and y1 < -150) or (
                                    x2 > -80 and x2 < 80 and y2 > -200 and y2 < -150):
                                print("Rear Door Unlock")
                            else:
                                print("Outside Unlock zone")
                    if (sol_len == 1):
                        arr1 = sol[0]
                        x1 = float(arr1[0])
                        y1 = float(arr1[1])
                        draw_uwb_tag(x1, y1, "TAG1(" + str(round(x1)) + "," + str(round(y1)) + ")", int_a, "CadetBlue1", t_a4)
                        draw_cycle(nearest[0], nearest[1], 5, "brown")
                        print(sol)
                        if (x1 > -80 and x1 < 80 and y1 > -150 and y1 < 50):
                            print("Inside Car, Engine can start")
                        elif (x1 > -150 and x1 < -80 and y1 > -200 and y1 < 100):
                            print("Left Side Door Unlock")
                        elif (x1 > 80 and x1 < 150 and y1 > -200 and y1 < 100):
                            print("Right Side Door Unlock")
                        elif (x1 > -80 and x1 < 80 and y1 > -200 and y1 < -150):
                            print("Rear Door Unlock")
                        else:
                            print("Outside Unlock zone")

                else:
                    print("Not possible to compute 1 & 3 circles intersection")
                    print("Computing 2 & 3 circles intersection")
                    # Solve the system of equations
                    sol = sp.solve((eq2, eq3), (x, y))
                    arr = sol[0]
                    m = arr[0]
                    n = arr[1]
                    if (not ('I' in str(n))):
                        print("Computing 2 & 3 circles intersection not have complex numbers")
                        sol_len = len(sol)
                        if (sol_len == 2):
                            arr1 = sol[0]
                            x1 = float(arr1[0])
                            y1 = float(arr1[1])
                            arr2 = sol[1]
                            x2 = float(arr2[0])
                            y2 = float(arr2[1])
                            print(sol)
                            if (int_a != 1):  # if A2 doesn't equal to default value 1
                                nearest = nearest_point_to_circle(x1, y1, x2, y2, -50, 0, int_a)
                                print(nearest)
                                draw_uwb_tag(nearest[0], nearest[1], "TAG1(" + str(int(nearest[0])) + "," + str(int(nearest[1])) + ")", int_a, "brown", t_a4)
                                draw_cycle(nearest[0], nearest[1], 5, "brown")
                                if (nearest[0] > -80 and nearest[0] < 80 and nearest[1] > -150 and nearest[1] < 50):
                                    print("Inside Car, Engine can start")
                                elif (nearest[0] > -150 and nearest[0] < -80 and nearest[1] > -200 and nearest[1] < 100):
                                    print("Left Side Door Unlock")
                                elif (nearest[0] > 80 and nearest[0] < 150 and nearest[1] > -200 and nearest[1] < 100):
                                    print("Right Side Door Unlock")
                                elif (nearest[0] > -80 and nearest[0] < 80 and nearest[1] > -200 and nearest[1] < -150):
                                    print("Rear Door Unlock")
                                else:
                                    print("Outside Unlock zone")
                            else:
                                draw_uwb_tag(x1, y1, "TAG1(" + str(round(x1)) + "," + str(round(y1)) + ")", int_b, "LightPink", t_a4)
                                draw_uwb_tag(x2, y2, "TAG2(" + str(round(x2)) + "," + str(round(y2)) + ")", int_b, "CadetBlue1", t_a4)
                                print(sol)
                                if (x1 > -80 and x1 < 80 and y1 > -150 and y1 < 50) or (
                                        x2 > -80 and x2 < 80 and y2 > -150 and y2 < 50):
                                    print("Inside Car, Engine can start")
                                elif (x1 > -150 and x1 < -80 and y1 > -200 and y1 < 100) or (
                                        x2 > -150 and x2 < -80 and y2 > -200 and y2 < 100):
                                    print("Left Side Door Unlock")
                                elif (x1 > 80 and x1 < 150 and y1 > -200 and y1 < 100) or (
                                        x2 > 80 and x2 < 150 and y2 > -200 and y2 < 100):
                                    print("Right Side Door Unlock")
                                elif (x1 > -80 and x1 < 80 and y1 > -200 and y1 < -150) or (
                                        x2 > -80 and x2 < 80 and y2 > -200 and y2 < -150):
                                    print("Rear Door Unlock")
                                else:
                                    print("Outside Unlock zone")
                        if (sol_len == 1):
                            arr1 = sol[0]
                            x1 = float(arr1[0])
                            y1 = float(arr1[1])
                            draw_uwb_tag(x1, y1, "TAG1(" + str(round(x1)) + "," + str(round(y1)) + ")", int_b, "LightPink", t_a4)
                            draw_cycle(nearest[0], nearest[1], 5, "brown")
                            print(sol)
                            if (x1 > -80 and x1 < 80 and y1 > -150 and y1 < 50):
                                print("Inside Car, Engine can start")
                            elif (x1 > -150 and x1 < -80 and y1 > -200 and y1 < 100):
                                print("Left Side Door Unlock")
                            elif (x1 > 80 and x1 < 150 and y1 > -200 and y1 < 100):
                                print("Right Side Door Unlock")
                            elif (x1 > -80 and x1 < 80 and y1 > -200 and y1 < -150):
                                print("Rear Door Unlock")
                            else:
                                print("Outside Unlock zone")

                    else:
                        print("Computing 2 & 3 circles intersection have complex numbers")
                        print("No circles intersection found")
        sleep(1)
        clean(t_a1)
        clean(t_a2)
        clean(t_a3)
        clean(t_a4)

    #turtle.mainloop()

if __name__ == '__main__':
    main()


